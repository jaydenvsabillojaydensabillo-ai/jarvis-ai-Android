# JARVIS Android starter app

This is an Android Studio project scaffold for an Android voice assistant. It is not a prebuilt APK.

## What it does
- Runs a microphone foreground service while enabled
- Uses Picovoice Porcupine's built-in JARVIS wake word
- Uses Android speech recognition after the wake word
- Speaks replies with Android TextToSpeech
- Opens a small allowlist of apps and websites
- Saves notes locally in Android SharedPreferences
- Can send questions to the OpenAI Responses API
- Reads time, date, and battery level

## Requirements
- Android Studio on a computer to build the APK
- Internet for Gradle dependencies and AI calls
- A Picovoice AccessKey from https://console.picovoice.ai/
- An OpenAI API key if you want online AI answers

## Build
1. Open Android Studio.
2. Choose Open and select this project folder.
3. Let Gradle sync.
4. Build > Build APK(s).
5. Install the APK on your phone and grant microphone permission.
6. Enter your Picovoice AccessKey in the app. Optionally enter your OpenAI API key.
7. Tap SAVE KEYS AND START LISTENING.
8. Keep the ongoing notification visible. Say "Hey JARVIS", wait for the prompt, then say a command.

## Commands
- "Hey JARVIS" then "what time is it"
- "Hey JARVIS" then "open YouTube"
- "Hey JARVIS" then "open Roblox"
- "Hey JARVIS" then "battery"
- "Hey JARVIS" then "remember my favorite game is Roblox"
- "Hey JARVIS" then "what do you remember"
- "Hey JARVIS" then "forget memory"
- Ask a normal question to use the configured AI API

## Important limitations
- A valid Picovoice AccessKey is required. The key is stored in app preferences for this starter project; do not share it or publish this project with your keys in it.
- AI requests use a cloud API and can cost money. Never share your API key.
- Speech recognition may use Google's or another installed recognition provider and may send recognized audio to that provider.
- This is a starter project, not a production-hardened assistant. Some Android/TECNO/itel battery-management settings can stop background microphone services.
- Android can stop the service if you force-stop the app, reboot the phone, revoke permissions, or restrict battery/background use. The app does not auto-start after reboot.
- The app uses a foreground notification while listening. It does not secretly listen: stop it with the app's STOP LISTENING button or Android's app controls.
- Some package names differ by device. App launching is limited to the names in the code.
- This scaffold has not been built or tested on your physical phone in this environment. Android Studio may require SDK or dependency adjustments.

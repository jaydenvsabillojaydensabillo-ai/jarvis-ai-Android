package com.example.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private var porcupineManager: PorcupineManager? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var aiKey = ""
    private var listeningForCommand = false
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("jarvis_settings", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1001, buildNotification("Waiting for Hey JARVIS"))
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pvKey = intent?.getStringExtra("picovoice_key")
            ?: prefs.getString("picovoice_key", "").orEmpty()
        aiKey = intent?.getStringExtra("ai_key")
            ?: prefs.getString("ai_key", "").orEmpty()

        if (pvKey.isBlank()) {
            say("Please open JARVIS and add your Picovoice access key.")
            stopSelf()
            return START_NOT_STICKY
        }
        startWakeEngine(pvKey)
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "jarvis_listener",
                "JARVIS listening",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "jarvis_listener")
                .setContentTitle("JARVIS is active")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("JARVIS is active")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1001, buildNotification(text))
    }

    private fun startWakeEngine(key: String) {
        try {
            porcupineManager?.delete()
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(key)
                .setBuiltInKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(applicationContext) {
                    onWakeWord()
                }
            porcupineManager?.start()
            updateNotification("Listening for Hey JARVIS")
        } catch (e: Exception) {
            say("Wake word setup failed. Check your Picovoice key and internet connection.")
            updateNotification("Wake word setup failed")
        }
    }

    private fun onWakeWord() {
        if (listeningForCommand) return
        listeningForCommand = true
        updateNotification("JARVIS heard you. Speak now.")
        try { porcupineManager?.stop() } catch (_: Exception) {}
        say("Yes sir?")
        startSpeechRecognition()
    }

    private fun startSpeechRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this device.")
            restartWakeEngine()
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    say("I did not catch that, sir.")
                    restartWakeEngine()
                }
                override fun onResults(results: android.os.Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (words.isBlank()) {
                        say("I did not catch that, sir.")
                        restartWakeEngine()
                    } else {
                        handleCommand(words)
                    }
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            say("Speech recognition could not start.")
            restartWakeEngine()
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower in listOf("stop listening", "turn off jarvis", "shutdown jarvis") -> {
                say("Going offline, sir.")
                stopSelf()
            }
            "what time" in lower || lower == "time" -> {
                say("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
                restartWakeEngine()
            }
            "what date" in lower || lower == "date" || "today's date" in lower -> {
                say("Today is " + java.text.SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(java.util.Date()))
                restartWakeEngine()
            }
            "battery" in lower -> {
                say(readBattery())
                restartWakeEngine()
            }
            lower.startsWith("open ") -> {
                openTarget(lower.removePrefix("open ").trim())
                restartWakeEngine()
            }
            lower.startsWith("remember ") -> {
                val note = command.substringAfter("remember ", "").trim()
                if (note.isNotEmpty()) {
                    val list = JSONArray(prefs.getString("memory", "[]"))
                    list.put(note)
                    prefs.edit().putString("memory", list.toString()).apply()
                    say("Saved to memory, sir.")
                } else say("What should I remember, sir?")
                restartWakeEngine()
            }
            lower.contains("what do you remember") -> {
                val list = JSONArray(prefs.getString("memory", "[]"))
                val notes = (0 until list.length()).map { list.optString(it) }
                say(if (notes.isEmpty()) "I have no saved notes, sir." else notes.takeLast(5).joinToString(". "))
                restartWakeEngine()
            }
            lower.startsWith("forget memory") -> {
                prefs.edit().putString("memory", "[]").apply()
                say("Memory cleared, sir.")
                restartWakeEngine()
            }
            else -> askAi(command)
        }
    }

    private fun openTarget(target: String) {
        val urls = mapOf(
            "youtube" to "https://www.youtube.com",
            "google" to "https://www.google.com",
            "chatgpt" to "https://chatgpt.com",
            "wikipedia" to "https://www.wikipedia.org"
        )
        if (target == "settings") {
            launch(Intent(android.provider.Settings.ACTION_SETTINGS))
            say("Opening settings, sir.")
            restartWakeEngine()
            return
        }
        val packages = mapOf(
            "roblox" to "com.roblox.client",
            "chrome" to "com.android.chrome",
            "youtube app" to "com.google.android.youtube"
        )
        val pkg = packages[target]
        if (pkg != null) {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launch(launchIntent)
                say("Opening $target, sir.")
            } else {
                say("I could not find that app, sir.")
            }
            return
        }
        val url = urls[target]
        if (url != null) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Opening $target, sir.")
        } else say("That app or website is not on my allowed list.")
    }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { say("Android blocked that action, sir.") }
    }

    private fun readBattery(): String {
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level", -1) ?: -1
        val scale = battery?.getIntExtra("scale", -1) ?: -1
        if (level < 0 || scale <= 0) return "I cannot read battery status."
        return "Battery is at ${level * 100 / scale} percent."
    }

    private fun askAi(question: String) {
        if (aiKey.isBlank()) {
            say("AI is not configured. Add an API key in the JARVIS app.")
            restartWakeEngine()
            return
        }
        updateNotification("Thinking")
        executor.execute {
            val answer = try {
                val url = URL("https://api.openai.com/v1/responses")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $aiKey")
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject()
                    .put("model", "gpt-4.1-mini")
                    .put("instructions", "You are JARVIS, a concise and helpful Android voice assistant. Never claim you performed actions you did not perform.")
                    .put("input", question)
                    .put("max_output_tokens", 220)
                    .toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                connection.disconnect()
                if (code !in 200..299) {
                    "AI request failed. Check your API key, access, or internet."
                } else {
                    val json = JSONObject(response)
                    val output = json.optJSONArray("output") ?: JSONArray()
                    val chunks = mutableListOf<String>()
                    for (i in 0 until output.length()) {
                        val item = output.optJSONObject(i) ?: continue
                        val content = item.optJSONArray("content") ?: continue
                        for (j in 0 until content.length()) {
                            val part = content.optJSONObject(j) ?: continue
                            if (part.optString("type") == "output_text") chunks.add(part.optString("text"))
                        }
                    }
                    chunks.joinToString(" ").ifBlank { "I got no answer back, sir." }
                }
            } catch (_: Exception) {
                "I could not connect to AI, sir."
            }
            runOnMain { say(answer); restartWakeEngine() }
        }
    }

    private fun runOnMain(action: () -> Unit) {
        android.os.Handler(mainLooper).post(action)
    }

    private fun restartWakeEngine() {
        listeningForCommand = false
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            porcupineManager?.start()
            updateNotification("Listening for Hey JARVIS")
        } catch (_: Exception) {
            updateNotification("Restart failed. Open JARVIS again.")
        }
    }

    private fun say(text: String) {
        runOnMain {
            try {
                if (tts?.isSpeaking == true) tts?.stop()
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
            } catch (_: Exception) {}
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
    }

    override fun onDestroy() {
        try { porcupineManager?.stop(); porcupineManager?.delete() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

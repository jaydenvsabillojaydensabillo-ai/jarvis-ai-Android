package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("jarvis_settings", MODE_PRIVATE) }
    private lateinit var accessKey: EditText
    private lateinit var aiKey: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 32f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Personal voice assistant"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        accessKey = EditText(this).apply {
            hint = "Picovoice AccessKey (wake word)"
            singleLine = true
            setText(prefs.getString("picovoice_key", ""))
        }
        aiKey = EditText(this).apply {
            hint = "Optional AI API key"
            singleLine = true
            setText(prefs.getString("ai_key", ""))
        }
        status = TextView(this).apply {
            text = "Setup needed. Add your Picovoice key to enable Hey JARVIS."
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
        }

        val start = Button(this).apply {
            text = "SAVE KEYS AND START LISTENING"
            setOnClickListener { saveAndStart() }
        }
        val stop = Button(this).apply {
            text = "STOP LISTENING"
            setOnClickListener {
                stopService(Intent(this@MainActivity, JarvisService::class.java))
                status.text = "JARVIS is stopped"
                Toast.makeText(this@MainActivity, "JARVIS stopped", Toast.LENGTH_SHORT).show()
            }
        }
        val info = TextView(this).apply {
            text = "Say “Hey JARVIS” after starting. Then speak a command. Listening is shown by Android's ongoing notification."
            textSize = 14f
            setPadding(0, pad, 0, 0)
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(accessKey)
        layout.addView(aiKey)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(status)
        layout.addView(info)
        setContentView(layout)
    }

    private fun saveAndStart() {
        val pvKey = accessKey.text.toString().trim()
        val openAiKey = aiKey.text.toString().trim()
        if (pvKey.isEmpty()) {
            status.text = "A Picovoice AccessKey is required for wake-word detection."
            return
        }
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 20)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 21)
        }
        prefs.edit().putString("picovoice_key", pvKey).putString("ai_key", openAiKey).apply()
        val intent = Intent(this, JarvisService::class.java).apply {
            putExtra("picovoice_key", pvKey)
            putExtra("ai_key", openAiKey)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            status.text = "Starting JARVIS. Keep its notification enabled."
        } catch (e: Exception) {
            status.text = "Could not start: ${e.message ?: "check permissions"}"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            saveAndStart()
        } else if (requestCode == 20) {
            status.text = "Microphone permission is required."
        }
    }
}
